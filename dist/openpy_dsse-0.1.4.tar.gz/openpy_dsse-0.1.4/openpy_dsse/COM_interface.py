# -*- coding: utf-8 -*-
# @Time    : 24/01/2023
# @Author  : Ing. Jorge Lara
# @Email   : jlara@iee.unsj.edu.ar
# @File    : ------------
# @Software: PyCharm

#import opendssdirect as drt
import py_dss_interface

dss = py_dss_interface.DSSDLL()